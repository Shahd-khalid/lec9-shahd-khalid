﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec9_shahd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            setenabel();
            Height = panel1.Top + 40;
            Random r = new Random();
            for (int n = 0; n < 10; n++)
            {
                int x = r.Next(100);
                listBox1.Items.Add(x);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            setenabel();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Text == "v")
            {
                Height = button15.Top + button15.Height + 50;
                button4.Text = "^";
            }
            else
            {
                button4.Text = "v";
                Height = panel1.Top + 40;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isnumoric(textBox1.Text.Trim()))
            {
                if (!repeated(listBox1, textBox1.Text))
                {
                    listBox1.Items.Add(textBox1.Text);
                    textBox1.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("the number is found");
                    textBox1.Clear();
                    textBox1.Focus();
                }
            }
            else
                MessageBox.Show("enter number");
            textBox1.Clear();
            textBox1.Focus();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int c = listBox1.Items.Count;
            for (int i = 0; i < c; i++)
            {
                if (!listBox2.Items.Contains(listBox1.Items[0]))
                {
                    listBox2.Items.Add(listBox1.Items[0]);
                    listBox1.Items.Remove(listBox1.Items[0]);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int c = listBox1.SelectedItems.Count;
            for (int i = 0; i < c; i++)
            {
                if (!repeated(listBox2, listBox1.SelectedItems[0].ToString()))
                {
                    listBox2.Items.Add(listBox1.SelectedItem);
                    listBox1.Items.Remove(listBox1.SelectedItem);

                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            if (radioButton1.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 == 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("not have even number");
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            if (radioButton2.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (Convert.ToInt32(listBox1.Items[i]) % 2 != 0)
                        listBox1.SelectedIndex = i;
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("not have oodd number");
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            bool flag = true;
            if (radioButton3.Checked)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    int n = Convert.ToInt32(listBox1.Items[i]);
                    flag = true;
                    for (int j = 2; j < n; j++)
                    {
                        if (n % j == 0)
                        {
                            flag = false;
                            break;
                        }
                        if (flag == true)
                            listBox1.SelectedIndex = i;
                        break;
                    }
                }
                if (listBox1.SelectedIndex == -1)
                    MessageBox.Show("not have praimare number");
            }
            
        }
           bool isnumoric(string element)
        {
            if (element == "")
                return false;
            for(int i=0;i<element.Length;i++)
            {
                if (element[i] < 48 || element[i] > 57)
                    return false;

            }
            return true;
        }
        bool repeated(ListBox l,string s)
        {
            for(int i=0;i<l.Items.Count;i++)
            {
                if (l.Items[i].ToString()==s)
                    return true;
            }
            return false;
        }

           private void sortanylistbox(ListBox l)
        {
            int t;
            int c =l.Items.Count;
            for(int i=0;i<c;i++)
            {
                for(int j=i+1;j<c;j++)
                {
                    int n1 = Convert.ToInt32(l.Items[i])
                        , n2 = Convert.ToInt32(l.Items[j]);
                    if(n1<n2)
                    {
                        t = n1;
                        l.Items[i] = n2;
                        l.Items[j] = t;
                    }
                }
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            sortanylistbox(listBox1);
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox1);
        }
        void setenabel()
        {
            button2.Enabled = listBox1.SelectedIndex > -1;
        }
        void revers(ListBox l)
        {
            for (int i = l.Items.Count - 1; i >= 0; i--)
            {
                l.Items.Add(l.Items[i]);
                l.Items.Remove(l.Items[i]);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Remove(listBox1.SelectedItem);
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            int n = listBox1.Items.Count;
            for (int i = 0; i < n; i++)
            {
                {
                    listBox2.Items.Add(listBox1.Items[listBox1.Items.Count - 1]);
                    listBox1.Items.Remove(listBox1.Items[listBox1.Items.Count - 1]);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (listBox2.SelectedIndex != -1)
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);
        }

        private void button8_Click(object sender, EventArgs e)
        {

            listBox2.Items.Clear();
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            sortanylistbox(listBox2);
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            revers(listBox2);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Add(textBox2.Text);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.SelectedItems.Remove(textBox3.Text);
        }

        private void button11_Click(object sender, EventArgs e)
        {

            listBox1.SelectedIndex = -1;
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
                        if (listBox1.Items.Count > 0)
            {
                for (int i = 0; i < listBox1.Items.Count; i++)
                {
                    listBox1.SelectedIndex = i;
                }
            }
            else
                MessageBox.Show("not found element");
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
             listBox1.SelectedIndex = -1;
        }

        private void button14_Click(object sender, EventArgs e)
        {
             textBox7.Text=listBox1.Items.Count.ToString();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox6.Text=listBox1.SelectedItems.Count.ToString();  
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox5.Text = (listBox1.Items.Count - listBox1.SelectedItems.Count).ToString();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
              int t;
            int c = listBox1.SelectedItems.Count;
            for(int i=listBox1.SelectedIndex;i<listBox1.SelectedIndex+c-1;i++)
            {
                for(int j=i+1;j<listBox1.SelectedIndex+c;j++)
                {
                    int n1 = Convert.ToInt32(listBox1.Items[i]), n2 = Convert.ToInt32(listBox1.Items[j]);
                    if(n1<n2)
                    {
                        t = n1;
                        listBox1.Items[i] = n2;
                        listBox1.Items[j] = t;
                    }
                }
                listBox1.SelectedIndex = i;
            }

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
    }

